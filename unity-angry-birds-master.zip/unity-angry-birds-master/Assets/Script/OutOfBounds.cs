using System.Collections;
using System.Collections.Generic;
using UnityEngine;



public class OutOfBounds : MonoBehaviour
{
    public GameObject bird;
    bool isBirdOutOfBounds;
    //public Bird redBird;

    /*private void OnTriggerEnter2D(Collider2D collision){
        if (collision.gameObject == bird){
            isBirdOutOfBounds = true;
        }
    }
    public void Update(){
        /*if(isBirdOutOfBounds){
            isBirdOutOfBounds = false;
            Debug.Log("bird collided...........");
            //bird.ResetBird();
            Instantiate(bird);
            Destroy(bird);
            
        }*/
    //}
}
